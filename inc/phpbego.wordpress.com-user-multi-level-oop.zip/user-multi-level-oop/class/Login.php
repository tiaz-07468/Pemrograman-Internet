<?php
/* 
 * http://phpbego.wordpress.com
 * Juli 2014
 */

class Login {
    
    // Properties
    private $db_connection = NULL;

    public $errors = array();
    public $messages = array();
    
    // Method Construct
    public function __construct($koneksi) {
        
        // $koneksi kita dapat dari halaman Index
        $this->db_connection = $koneksi;
        
        // Mulai session
        session_start();
        
        // Jika ada perintah logout
        if (isset($_GET['logout'])){
            $this->doLogout();
        }
        
        if (isset($_POST['prclogin'])){
            $this->doLogin();
        }
    }
    
    private function doLogin(){
        if (!$this->db_connection->connect_errno){
            
            $username = $this->db_connection->real_escape_string($_POST['user__name']);
            $password = $this->db_connection->real_escape_string($_POST['pass__word']);
            
            $sql = "SELECT * FROM tb_users WHERE username=$username AND password=$password";
            $result = $this->db_connection->query($sql);
            
            if ($result->num_rows == 1){
                $result_row = $result->fetch_object();
                
                $_SESSION['username'] = $result_row->username;
                $_SESSION['hak_akses'] = $result_row->hak_akses;
                $_SESSION['user_login'] = 1;
            } else {
                $this->errors[] = "Username atau Password Salah!";
            }
            
        }
    }
    
    public function doLogout()
    {
        // delete the session of the user
        $_SESSION = array();
        session_destroy();
        // return a little feeedback message
        $this->messages[] = "You have been logged out.";
        header('location: index.php');
    }
    
    public function isUserLogin() {
        if (isset($_SESSION['user_login'])){
            return TRUE;
        } else {
            return FALSE;
        }
        
    }
    
    public function showMenu(){
        $hak_akses = $_SESSION['hak_akses'];
        $sql = $this->db_connection->query("SELECT * FROM tb_menu WHERE LOCATE(hak_akses, $hak_akses) ORDER BY id");
        
        while ($row = $sql->fetch_array()){
            $data[] = $row;
        }
        return $data;
    }
}


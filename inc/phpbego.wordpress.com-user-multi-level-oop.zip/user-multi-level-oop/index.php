<?php
/* 
 * http://phpbego.wordpress.com
 * Juli 2014
 */

require_once 'config/Koneksi.php';

// Instantisasi Koneksi
$db = new Koneksi();
$koneksi = $db->getConnection();

require_once 'class/Login.php';

// Instantisasi Login($koneksi)
$login = new Login($koneksi);

if ($login->isUserLogin() == TRUE){
    include "views/dashboard.php";
} else {
    include "views/login.php";
}



<?php
/* 
 * http://phpbego.wordpress.com
 * Juli 2014
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Login Multi Level Menggunakan PHP dengan Teknik OOP</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <h2>Login Multi Level Menggunakan PHP dengan Teknik OOP</h2>
            <div class="row">                
                <div class="col-sm-4">
                    <form class="well" method="POST" action="index.php">
                        <label>Username : </label><input class="form-control" type="text" name="user__name" required>
                        <label>Password : </label><input class="form-control" type="password" name="pass__word"  required>
                        <div>&nbsp;</div>
                        <input class="btn btn-info" type="submit" name="prclogin" value="LOGIN">
                    </form>
                </div>
            </div>

            <table class="table table-bordered">
                <tr>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Hak Akses</th>
                </tr>
                <tr>
                    <td>Administrator</td>
                    <td>001</td>
                    <td>12345</td>
                    <td>Semua</td>
                </tr>
                <tr>
                    <td>Kepala Sekolah</td>
                    <td>002</td>
                    <td>12345</td>
                    <td>Kepala Sekolah, Wali Kelas, Guru</td>
                </tr>
                <tr>
                    <td>Wali Kelas</td>
                    <td>003</td>
                    <td>12345</td>
                    <td>Wali Kelas, Guru</td>
                </tr>
                <tr>
                    <td>Guru</td>
                    <td>004</td>
                    <td>12345</td>
                    <td>Guru</td>
                </tr>
            </table>
        </div>
    </body>
</html>
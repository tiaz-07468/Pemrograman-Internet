<?php
/* 
 * http://phpbego.wordpress.com
 * Juli 2014
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Dashboard ::: Login Multi Level Menggunakan PHP dengan Teknik OOP</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php">Home</a></li>
                        <?php
                        // Menu dari Method showMenu di class Login.php
                        $menus = $login->showMenu();
                        
                        foreach ($menus as $menu) {
                            echo "<li><a href='./?page=" . $menu['link'] . "'>" . $menu['nama'] . "</a></li>";
                        }
                        ?>                        
                        <li><a href="./?logout">Logout</a></li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </div>

        <div class="container">
            <div style="height: 80px;"></div>
            <div class="well">
                <h1>Selamat Datang <?php echo $_SESSION['username']; ?> di Dashboard</h1>      
            </div>
            Hak Akses anda :
            <div class="btn-group">
                <?php
                foreach ($menus as $menu) {
                    echo "<button class='btn btn-success'>" . $menu['nama'] . "</button>";
                }
                ?>
            </div>
                <?php
                if (isset($_GET['page'])){
                    if (file_exists($_GET['page'].".php")){
			require ($_GET['page'].".php");
                    }
                    else {
                        require ("views/empty.php");
                    }
                }
                ?>
        </div>
    </body>
</html>
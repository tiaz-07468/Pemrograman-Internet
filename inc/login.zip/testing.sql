-- phpMyAdmin SQL Dump
-- version 4.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 26, 2014 at 11:01 AM
-- Server version: 5.5.37-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testing`
--
CREATE DATABASE IF NOT EXISTS `testing` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `testing`;

-- --------------------------------------------------------

--
-- Table structure for table `multiuser`
--

CREATE TABLE IF NOT EXISTS `multiuser` (
`id_user` int(11) NOT NULL,
  `nama_lengkap` varchar(80) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type_user` enum('admin','editor','user') NOT NULL,
  `tgl` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `multiuser`
--

INSERT INTO `multiuser` (`id_user`, `nama_lengkap`, `username`, `password`, `type_user`, `tgl`) VALUES
(1, 'Ghazali samudra', 'ghazali', '5b3cdd7dafc8dca65b3cd633241b2646', 'admin', '2014-06-26 10:39:52'),
(2, 'Andrian Saputra', 'andre', '582d74b3e980c1915e16fe6326bfda3d', 'editor', '2014-06-26 10:40:53'),
(3, 'Jamil Ahmad', 'jamil', '61243c7b9a4022cb3f8dc3106767ed12', 'user', '2014-06-26 10:41:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `multiuser`
--
ALTER TABLE `multiuser`
 ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `multiuser`
--
ALTER TABLE `multiuser`
MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

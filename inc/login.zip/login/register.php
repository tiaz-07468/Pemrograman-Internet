<form action="" method="post"/>
<p>
     <label>Nama Lengkap</label>
     <input type="text" name="nm"/>
</p>
<p>
     <label>Username</label>
     <input type="text" name="user"/>
</p>
<p>
     <label>Password</label>
     <input type="password" name="pass1"/>
</p>
<p>
     <label>Konfirmasi Password</label>
     <input type="password" name="pass2"/>
</p>
<p>
     <label>Type Member</label>
     <select name="type">
          <option value="user">User Biasa</option>
          <option value="editor">Editor</option>
          <option value="admin">Administrator</option>
     </select>
</p>
<p>
     <input type="submit" name="reg" value="Register"/>
     <a href="login.php">Login</a>
</p>
</form>
<?php
include "koneksi.php";
if(isset($_POST['reg'])){
     $nm=$_POST['nm'];
     $user=$_POST['user'];
     $pass1=$_POST['pass1'];
     $pass2=$_POST['pass2'];
     $type=$_POST['type'];
     $tgl=date('Y-m-d H:i:s');
     if($pass1==$pass2){
          $pass=md5($pass1);
          $hasil=mysql_query("insert into multiuser values('','$nm','$user','$pass','$type','$tgl')");
          if($hasil){
               echo '
               <script>
               var conn=confirm("Berhasil Register User, Apa mau lanjut ke Menu Login");
               if(conn==true){
                    window.location.assign("login.php");
               }
               </script>
               ';
          }
     }
}
?>

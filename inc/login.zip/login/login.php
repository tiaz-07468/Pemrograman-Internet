<form action="" method="post">
<p>
     <label>Username</label>
     <input type="text" name="username"/>
</p>
<p>
     <label>Password</label>
     <input type="password" name="password"/>
</p>
<p>
     <input type="submit" name="log" value="Login"/>
     <a href="register.php">Register</a>
</p>
</form>
<?php
include "koneksi.php";
if(isset($_POST['log'])){
     $user=$_POST['username'];
     $pass=md5($_POST['password']);
     $res=mysql_query("select * from multiuser where username='$user' and password='$pass'");
     $data=mysql_fetch_array($res);
     $nm=$data['nama_lengkap'];
     $name=$data['username'];
     $word=$data['password'];
     $type=$data['type_user'];
     if($user==$name && $pass==$word){
          if($type=="admin"){
               session_start();
               $_SESSION['nama_lengkap']=$nm;
               $_SESSION['username']=$name;
               $_SESSION['type_user']=$type;
               echo '<script>window.location.assign("index.php")</script>';
          } else if($type=="editor"){
               session_start();
               $_SESSION['nama_lengkap']=$nm;
               $_SESSION['username']=$name;
               $_SESSION['type_user']=$type;
               echo '<script>window.location.assign("index.php")</script>';
          } else{
               session_start();
               $_SESSION['nama_lengkap']=$nm;
               $_SESSION['username']=$name;
               $_SESSION['type_user']=$type;
               echo '<script>window.location.assign("index.php")</script>';
          }
     }
}
?>
